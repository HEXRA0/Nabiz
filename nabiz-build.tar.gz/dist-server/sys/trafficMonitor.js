import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import util from 'util';
const execAsync = util.promisify(exec);
// Log directories to search
const LOG_DIRS = [
    'C:\\Caddy\\logs',
    'C:/Caddy/logs',
    path.resolve(process.cwd(), 'data/logs'),
    path.resolve(process.cwd(), 'logs'),
];
// Track file read offsets so we only read new lines
const fileOffsets = new Map();
// In-memory logs ring buffer (keep last 500 logs)
const MAX_LOGS = 500;
let recentLogs = [];
const minuteBuckets = new Map();
// Project port mappings for active TCP connection tracking
const PROJECT_PORTS = {
    nabiz: 3001,
    odak: 4173,
    thedemir: 80,
};
// Active connections count cache
let activeConnections = {
    nabiz: 0,
    odak: 0,
    thedemir: 0,
    total: 0,
};
function formatBytes(bytes) {
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024)
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
function getMinuteKey(date) {
    const pad = (n) => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
// Parse a single Caddy JSON log line
function parseCaddyLine(line, fallbackProject) {
    try {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith('{'))
            return null;
        const data = JSON.parse(trimmed);
        const req = data.request || {};
        const headers = req.headers || {};
        const host = req.host || '';
        let project = fallbackProject || 'unknown';
        if (host.includes('odak'))
            project = 'odak';
        else if (host.includes('nabiz'))
            project = 'nabiz';
        else if (host.includes('thedemir'))
            project = 'thedemir';
        // Cloudflare IP & Country headers or direct client IP
        const cfIp = headers['Cf-Connecting-Ip']?.[0] || headers['X-Forwarded-For']?.[0];
        const clientIp = cfIp || req.client_ip || req.remote_ip || '127.0.0.1';
        const country = headers['Cf-Ipcountry']?.[0] || 'TR';
        const userAgent = headers['User-Agent']?.[0] || '';
        // Duration is in seconds (floating point) in Caddy
        const durationSec = typeof data.duration === 'number' ? data.duration : 0;
        const durationMs = Math.round(durationSec * 1000 * 10) / 10;
        const uri = req.uri || '/';
        const urlPath = uri.split('?')[0] || '/';
        const status = typeof data.status === 'number' ? data.status : 200;
        const sizeBytes = typeof data.size === 'number' ? data.size : (typeof data.bytes_read === 'number' ? data.bytes_read : 0);
        const tsSeconds = typeof data.ts === 'number' ? data.ts : Date.now() / 1000;
        const timestamp = Math.floor(tsSeconds * 1000);
        const date = new Date(timestamp);
        const timeFormatted = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
        const id = `${timestamp}-${Math.random().toString(36).substring(2, 7)}`;
        return {
            id,
            timestamp,
            timeFormatted,
            project,
            host,
            method: req.method || 'GET',
            uri,
            path: urlPath,
            status,
            durationMs,
            sizeBytes,
            clientIp,
            country,
            userAgent,
        };
    }
    catch {
        return null;
    }
}
// Ingest a batch of log entries into memory & aggregates
export function ingestLogs(entries) {
    if (!entries || entries.length === 0)
        return;
    for (const entry of entries) {
        // Add to recent logs
        recentLogs.unshift(entry);
        // Update minute bucket
        const date = new Date(entry.timestamp);
        const mKey = getMinuteKey(date);
        let bucket = minuteBuckets.get(mKey);
        if (!bucket) {
            bucket = {
                minuteKey: mKey,
                timestamp: new Date(mKey.replace(' ', 'T') + ':00').getTime(),
                requests: 0,
                errors: 0,
                totalDurationMs: 0,
            };
            minuteBuckets.set(mKey, bucket);
        }
        bucket.requests++;
        if (entry.status >= 400)
            bucket.errors++;
        bucket.totalDurationMs += entry.durationMs;
    }
    // Trim recent logs
    if (recentLogs.length > MAX_LOGS) {
        recentLogs = recentLogs.slice(0, MAX_LOGS);
    }
    // Prune minute buckets older than 2 hours
    const twoHoursAgo = Date.now() - 2 * 60 * 60 * 1000;
    for (const [key, bucket] of minuteBuckets.entries()) {
        if (bucket.timestamp < twoHoursAgo) {
            minuteBuckets.delete(key);
        }
    }
}
// Read log files
async function pollLogFiles() {
    // Find log files in known locations
    const filesToRead = [];
    for (const dir of LOG_DIRS) {
        try {
            if (fs.existsSync(dir)) {
                const files = fs.readdirSync(dir);
                for (const file of files) {
                    if (file.endsWith('.log')) {
                        const project = file.replace('.log', '');
                        filesToRead.push({ filePath: path.join(dir, file), project });
                    }
                }
            }
        }
        catch { }
    }
    const newEntries = [];
    for (const { filePath, project } of filesToRead) {
        try {
            const stats = fs.statSync(filePath);
            const currentOffset = fileOffsets.get(filePath) || 0;
            if (stats.size > currentOffset) {
                const buffer = Buffer.alloc(stats.size - currentOffset);
                const fd = fs.openSync(filePath, 'r');
                fs.readSync(fd, buffer, 0, buffer.length, currentOffset);
                fs.closeSync(fd);
                fileOffsets.set(filePath, stats.size);
                const content = buffer.toString('utf-8');
                const lines = content.split('\n');
                for (const line of lines) {
                    const parsed = parseCaddyLine(line, project);
                    if (parsed) {
                        newEntries.push(parsed);
                    }
                }
            }
            else if (stats.size < currentOffset) {
                // File truncated/rotated, reset offset
                fileOffsets.set(filePath, 0);
            }
        }
        catch { }
    }
    if (newEntries.length > 0) {
        // Sort chronologically before ingesting
        newEntries.sort((a, b) => a.timestamp - b.timestamp);
        ingestLogs(newEntries);
    }
}
// Poll active TCP connections per port
async function pollActiveConnections() {
    try {
        const isWindows = process.platform === 'win32';
        let output = '';
        if (isWindows) {
            const { stdout } = await execAsync('netstat -ano');
            output = stdout;
        }
        else {
            const { stdout } = await execAsync('netstat -an | grep ESTABLISHED || true');
            output = stdout;
        }
        const counts = {
            nabiz: 0,
            odak: 0,
            thedemir: 0,
            total: 0,
        };
        for (const [proj, port] of Object.entries(PROJECT_PORTS)) {
            const regex = new RegExp(`:${port}\\s+.*ESTABLISHED`, 'gi');
            const matches = output.match(regex);
            counts[proj] = matches ? matches.length : 0;
        }
        counts.total = Object.values(counts).reduce((a, b) => a + b, 0);
        activeConnections = counts;
    }
    catch { }
}
// Compute comprehensive summary and domain-level metrics
export function getTrafficSummary() {
    const now = Date.now();
    const oneHourAgo = now - 3600 * 1000;
    const oneMinuteAgo = now - 60 * 1000;
    let totalRequests = recentLogs.length;
    let totalBytes = 0;
    let totalDuration = 0;
    let reqsInLastMinute = 0;
    const statusCodes = { '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0 };
    const domainMap = {
        odak: { logs: [], bytes: 0, duration: 0, statusCodes: { '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0 }, pathCounts: new Map(), countryCounts: new Map() },
        thedemir: { logs: [], bytes: 0, duration: 0, statusCodes: { '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0 }, pathCounts: new Map(), countryCounts: new Map() },
        nabiz: { logs: [], bytes: 0, duration: 0, statusCodes: { '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0 }, pathCounts: new Map(), countryCounts: new Map() },
    };
    for (const log of recentLogs) {
        totalBytes += log.sizeBytes;
        totalDuration += log.durationMs;
        if (log.timestamp >= oneMinuteAgo) {
            reqsInLastMinute++;
        }
        if (log.status >= 200 && log.status < 300)
            statusCodes['2xx']++;
        else if (log.status >= 300 && log.status < 400)
            statusCodes['3xx']++;
        else if (log.status >= 400 && log.status < 500)
            statusCodes['4xx']++;
        else if (log.status >= 500)
            statusCodes['5xx']++;
        const dKey = domainMap[log.project] ? log.project : 'thedemir';
        const dObj = domainMap[dKey];
        dObj.logs.push(log);
        dObj.bytes += log.sizeBytes;
        dObj.duration += log.durationMs;
        if (log.status >= 200 && log.status < 300)
            dObj.statusCodes['2xx']++;
        else if (log.status >= 300 && log.status < 400)
            dObj.statusCodes['3xx']++;
        else if (log.status >= 400 && log.status < 500)
            dObj.statusCodes['4xx']++;
        else if (log.status >= 500)
            dObj.statusCodes['5xx']++;
        // Path count
        const pStat = dObj.pathCounts.get(log.path) || { count: 0, totalDuration: 0 };
        pStat.count++;
        pStat.totalDuration += log.durationMs;
        dObj.pathCounts.set(log.path, pStat);
        // Country count
        const cCount = dObj.countryCounts.get(log.country) || 0;
        dObj.countryCounts.set(log.country, cCount + 1);
    }
    // Build domain stats
    const domains = {};
    for (const [proj, dObj] of Object.entries(domainMap)) {
        const projLogs = dObj.logs;
        const projReqLastHour = projLogs.filter((l) => l.timestamp >= oneHourAgo).length;
        const projReqLastMin = projLogs.filter((l) => l.timestamp >= oneMinuteAgo).length;
        const topPaths = Array.from(dObj.pathCounts.entries())
            .map(([path, data]) => ({
            path,
            count: data.count,
            avgDurationMs: Math.round((data.totalDuration / data.count) * 10) / 10,
        }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 10);
        const topCountries = Array.from(dObj.countryCounts.entries())
            .map(([code, count]) => ({ code, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 6);
        domains[proj] = {
            project: proj,
            host: proj === 'odak' ? 'odak.thedemir.com' : proj === 'nabiz' ? 'nabiz.thedemir.com' : 'thedemir.com',
            activeConnections: activeConnections[proj] || 0,
            totalRequests: projLogs.length,
            requestsLastHour: projReqLastHour,
            requestsPerSec: Math.round((projReqLastMin / 60) * 10) / 10,
            totalBytes: dObj.bytes,
            avgDurationMs: projLogs.length > 0 ? Math.round((dObj.duration / projLogs.length) * 10) / 10 : 0,
            statusCodes: dObj.statusCodes,
            topPaths,
            topCountries,
        };
    }
    // Build last 30 minutes time-series
    const historySeries = [];
    const sortedBuckets = Array.from(minuteBuckets.values()).sort((a, b) => a.timestamp - b.timestamp);
    // If no buckets, create current minute empty bucket
    if (sortedBuckets.length === 0) {
        const d = new Date();
        historySeries.push({
            timestamp: d.getTime(),
            time: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`,
            requests: 0,
            errors: 0,
            avgLatency: 0,
        });
    }
    else {
        for (const b of sortedBuckets.slice(-30)) {
            const d = new Date(b.timestamp);
            historySeries.push({
                timestamp: b.timestamp,
                time: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`,
                requests: b.requests,
                errors: b.errors,
                avgLatency: b.requests > 0 ? Math.round((b.totalDurationMs / b.requests) * 10) / 10 : 0,
            });
        }
    }
    return {
        totalActiveConnections: activeConnections.total || 0,
        totalRequests,
        requestsPerSec: Math.round((reqsInLastMinute / 60) * 10) / 10,
        totalBytes,
        totalBytesFormatted: formatBytes(totalBytes),
        avgDurationMs: totalRequests > 0 ? Math.round((totalDuration / totalRequests) * 10) / 10 : 0,
        statusCodes,
        historySeries,
        domains,
        recentLogs: recentLogs.slice(0, 100),
    };
}
// Background scheduler
let monitorInterval = null;
export function startTrafficMonitoring() {
    // Create data/logs directory if not exists
    const localLogsDir = path.resolve(process.cwd(), 'data/logs');
    if (!fs.existsSync(localLogsDir)) {
        try {
            fs.mkdirSync(localLogsDir, { recursive: true });
        }
        catch { }
    }
    // Initial poll
    pollLogFiles();
    pollActiveConnections();
    // Poll every 1.5 seconds for fresh logs and netstat
    if (!monitorInterval) {
        monitorInterval = setInterval(async () => {
            await Promise.all([pollLogFiles(), pollActiveConnections()]);
        }, 1500);
    }
}
