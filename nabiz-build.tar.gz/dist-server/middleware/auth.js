import jwt from 'jsonwebtoken';
import { CONFIG } from '../config.js';
import { db } from '../db/index.js';
export function requireAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Yetkilendirme belirteci (token) eksik veya geçersiz.' });
    }
    const token = authHeader.substring(7);
    try {
        const decoded = jwt.verify(token, CONFIG.JWT_SECRET);
        const user = db.prepare('SELECT id, username, email, role FROM users WHERE id = ?').get(decoded.id);
        if (!user) {
            return res.status(401).json({ error: 'Kullanıcı bulunamadı.' });
        }
        req.user = user;
        next();
    }
    catch (err) {
        return res.status(401).json({ error: 'Oturum süresi dolmuş veya geçersiz token.' });
    }
}
